#include "oled_helper.h"

void OLED_Print(const char *bigText, const char *smallText1, const char *smallText2)
{
    SSD1306_Clear();

    // Büyük yazı (her zaman 0,0’a)
    if (bigText && strlen(bigText) > 0) {
        SSD1306_GotoXY(0, 0);
        SSD1306_Puts((char*)bigText, &Font_11x18, 1);
    }

    // Küçük yazılar 20px aşağıdan başlar
    int y = 20;
    if (smallText1 && strlen(smallText1) > 0) {
        SSD1306_GotoXY(0, y);
        SSD1306_Puts((char*)smallText1, &Font_7x10, 1);
        y += 20;
    }

    if (smallText2 && strlen(smallText2) > 0) {
        SSD1306_GotoXY(0, y);
        SSD1306_Puts((char*)smallText2, &Font_7x10, 1);
        y += 20;
    }

    SSD1306_UpdateScreen();
}

void OLED_PrintVar(const char *label, int intVal, float floatVal)
{
    char buffer[32];

    SSD1306_Clear();

    // Label yaz
    if (label && strlen(label) > 0) {
        SSD1306_GotoXY(0, 0);
        SSD1306_Puts((char*)label, &Font_11x18, 1);
    }

    // Integer yaz
    snprintf(buffer, sizeof(buffer), "Int: %d", intVal);
    SSD1306_GotoXY(0, 20);
    SSD1306_Puts(buffer, &Font_7x10, 1);

    // Float yaz
    snprintf(buffer, sizeof(buffer), "Float: %.2f", floatVal);
    SSD1306_GotoXY(0, 40);
    SSD1306_Puts(buffer, &Font_7x10, 1);

    SSD1306_UpdateScreen();
}

void OLED_PrintVar2(const char *label, int intVal, const char *message)
{
    char buffer[16];  // sayı için küçük bir buffer

    SSD1306_Clear();

    // 1. Satır: label (örnek: "Starting")
    if (label && strlen(label) > 0) {
        SSD1306_GotoXY(0, 0);
        SSD1306_Puts((char*)label, &Font_11x18, 1);
    }

    // 2. Satır: int değeri (örnek: 5)
    snprintf(buffer, sizeof(buffer), "%d", intVal);
    SSD1306_GotoXY(0, 20);
    SSD1306_Puts(buffer, &Font_11x18, 1);

    // 3. Satır: mesaj (örnek: "Please wait")
    if (message && strlen(message) > 0) {
        SSD1306_GotoXY(0, 40);
        SSD1306_Puts((char*)message, &Font_7x10, 1);
    }

    SSD1306_UpdateScreen();
}


void OLED_DrawIBM(void)
{
    SSD1306_Clear();

    SSD1306_GotoXY(0, 0);
    SSD1306_Puts("IIII BBBBB  M    M", &Font_7x10, 1);

    SSD1306_GotoXY(0, 12);
    SSD1306_Puts(" I   B   B  MM  MM", &Font_7x10, 1);

    SSD1306_GotoXY(0, 24);
    SSD1306_Puts(" I   BBBBB  M M M", &Font_7x10, 1);

    SSD1306_GotoXY(0, 36);
    SSD1306_Puts(" I   B   B  M    M", &Font_7x10, 1);

    SSD1306_GotoXY(0, 48);
    SSD1306_Puts("IIII BBBBB  M    M", &Font_7x10, 1);

    SSD1306_UpdateScreen();
}


