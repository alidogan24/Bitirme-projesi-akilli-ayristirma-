/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "fonts.h"
#include "ssd1306.h"
#include "string.h" // strlen için
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define RELAY_PORT GPIOA
#define RELAY_PIN  GPIO_PIN_8
#define SENSOR_PORT GPIOB
#define SENSOR_PIN  GPIO_PIN_12
#define WARNSENSOR_PORT GPIOB
#define WARNSENSOR_PIN  GPIO_PIN_14
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

RTC_HandleTypeDef hrtc;

TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM3_Init(void);
static void MX_RTC_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// UART'tan gelen veriyi saklamak için buffer
#define RX_BUFFER_SIZE 100
uint8_t rx_buffer[RX_BUFFER_SIZE];
uint8_t rx_index = 0;
uint8_t rx_data; // Gelen tek bayt veri
int done = 0;  // for döngüsünün sadece bir kez çalışması için bayrak

//realy kısımları---------------------
typedef enum {
    WAIT_WARN = 0,     // Warn sensörünü bekle
    BLINK_RELAY,      // Röleyi 0.3 sn aralıkla aç-kapa yap
    WAIT_SENSOR,     // Sensor pininin tetiklenmesini bekle
    PROCESS,         // Sensör geldi, işlemleri yap
	WAIT_ESP
} SystemState;

SystemState state = WAIT_WARN;

//kol için hazırlık-------------------------
typedef enum {
    OBJ_NONE = 0,
    OBJ_PLASTIC,
    OBJ_METAL,
    OBJ_GLASS
} ObjectType;

volatile ObjectType detectedObject = OBJ_NONE;
volatile uint16_t detectedDistance = 0;
volatile uint8_t capture_done = 0;
volatile uint8_t line_ready = 0;
uint32_t sensorLowTimer = 0;
uint8_t sensorConfirmed = 0;
uint32_t espTimer = 0;
uint8_t espRetryCount = 0;
//kol için ek pvler-----------------------
uint32_t my_arr = 999;
extern float current_x = 0.0f; // Robotun o anki grafik konumu
// Ara değer hesaplama (Lineer İnterpolasyon)
float lerp(float x, float x1, float x2, float y1, float y2) {
    return y1 + (x - x1) * (y2 - y1) / (x2 - x1);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  MX_RTC_Init();
  /* USER CODE BEGIN 2 */
  // UART kesmesini başlat
  HAL_UART_Receive_IT(&huart1, &rx_data, 1);
  SSD1306_Init();

  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);



  char msg[] = "Hello-ESP32!\r\n";
	HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
	uint8_t sensor_was_active = 0;

	uint32_t relayTimer = 0;
	uint8_t relayState = 0;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	    if (!done)  // sadece bir kez girsin
	    {
	        for (int i = 0; i < 6; i++) {
	        	OLED_PrintVar2("Starting", i, "Please wait");
	        	HAL_UART_Transmit(&huart1, (uint8_t*)"STM32-STARTING\r\n", 17, HAL_MAX_DELAY);
	            HAL_Delay(1000);
	        }
	        done = 1; // bir kere çalıştıktan sonra tekrar girmesin
	        Set_PWM_Duty_TIM3(1, 70); //PA6  Taban (20-120 def-70)
	        Set_PWM_Duty_TIM3(2, 60); //PA7  Omuz (def-60)
	        Set_PWM_Duty_TIM3(3, 75); //PB0  dirsek (def-75 , max-99)
	        HAL_GPIO_WritePin(RELAY_PORT, RELAY_PIN, GPIO_PIN_SET);
	        OLED_Print("Waiting"," "," ");

	    }

	    uint32_t now = HAL_GetTick();
	    GPIO_PinState sensor = HAL_GPIO_ReadPin(SENSOR_PORT, SENSOR_PIN);
	    GPIO_PinState warnsensor = HAL_GPIO_ReadPin(WARNSENSOR_PORT,WARNSENSOR_PIN);




	    switch(state)
	    {
	        //-----------------------------------------
	        case WAIT_WARN:
	            if (warnsensor == GPIO_PIN_RESET)
	            {
	                OLED_Print("WARN", "TRIGGERED", "");
	                relayTimer = now;
	                state = BLINK_RELAY;
	            }
	            break;

	        //-----------------------------------------
	        case BLINK_RELAY:

	            // Sensör LOW oldu mu?
	            if (sensor == GPIO_PIN_RESET)
	            {
	                // LOW ilk kez olduysa zaman başlat
	                if (sensorLowTimer == 0)
	                    sensorLowTimer = now;

	                // 100ms boyunca LOW kaldı mı?
	                if (now - sensorLowTimer >= 100)
	                {
	                    // Artık bu GERÇEK bir cisim → Röleyi sürekli çalıştır
	                    HAL_GPIO_WritePin(RELAY_PORT, RELAY_PIN, GPIO_PIN_SET);
	                    relayState = 1;
	                }
	            }
	            else   // sensör HIGH oldu
	            {
	                // Eğer önceden onaylanmış bir cisim vardıysa
	                if (relayState == 1)
	                {
	                    // Cisim çıktı → röleyi durdur ve işleme geç
	                    HAL_GPIO_WritePin(RELAY_PORT, RELAY_PIN, GPIO_PIN_RESET);
	                    relayState = 0;
	                    sensorLowTimer = 0;
	                    state = PROCESS;
	                }
	                else
	                {
	                    // Daha 100ms dolmadan HIGH olduysa → iptal
	                    sensorLowTimer = 0;
	                }
	            }

	            break;

	        //-----------------------------------------
	        case PROCESS:
	            OLED_Print("SENSOR", "CONFIRMED", "");

	            capture_done = 0;
	            detectedObject = OBJ_NONE;
	            detectedDistance = 0;

	            espRetryCount = 0;     // yeni yakalama döngüsü
	            ESP_SendCapture();    // ilk capture
	            espTimer = now;       // zaman başlat

	            state = WAIT_ESP;
	            break;

	        //-----------------------------------------
	        case WAIT_ESP:

	            // UART’tan satır geldiyse parse et
	            if (line_ready)
	            {
	                line_ready = 0;
	                ParseObjectData((char*)rx_buffer);
	            }

	            // ✔ ESP cevap verdi
	            if (capture_done)
	            {
	                char l1[20];
	                char l2[20];

	                if (detectedObject == OBJ_METAL)
	                    sprintf(l1, "Cisim: METAL");
	                else if (detectedObject == OBJ_PLASTIC)
	                    sprintf(l1, "Cisim: PLASTIC");
	                else if (detectedObject == OBJ_GLASS)
	                    sprintf(l1, "Cisim: GLASS");
	                else
	                    sprintf(l1, "Cisim: NONE");

	                sprintf(l2, "Mesafe:%d", detectedDistance);
	                OLED_Print(l1, l2, "");

	                switch(detectedObject)
	                {
	                    case OBJ_METAL:
	                        OLED_Print("Process", "METAL", "");
	                        OLED_PrintVar2("GO TO", detectedDistance, "Please wait");
	                        Metal_Object();
	                        break;

	                    case OBJ_PLASTIC:
	                        OLED_Print("Process", "PLASTIC", "");
	                        OLED_PrintVar2("GO TO", detectedDistance, "Please wait");
	                        Plastic_Object();
	                        break;

	                    case OBJ_GLASS:
	                        OLED_Print("Process", "GLASS", "");
	                        OLED_PrintVar2("GO TO", detectedDistance, "Please wait");
	                        Glass_Object();
	                        break;

	                    default:
	                        OLED_Print("No object", "", "");
	                        break;
	                }

	                HAL_GPIO_WritePin(RELAY_PORT, RELAY_PIN, GPIO_PIN_SET);
	                state = WAIT_WARN;    // sistem sıfırlanır
	            }

	            // ❗ 5 saniye cevap gelmedi → tekrar capture
	            else if (now - espTimer >= 5000)
	            {
	                espRetryCount++;

	                if (espRetryCount < 3)
	                {
	                    OLED_Print("ESP", "RETRY", "");
	                    ESP_SendCapture();   // tekrar foto iste
	                    espTimer = now;      // süreyi sıfırla
	                }
	                else
	                {
	                    OLED_Print("ESP", "FAILED", "");
	                    HAL_GPIO_WritePin(RELAY_PORT, RELAY_PIN, GPIO_PIN_SET);
	                    state = WAIT_WARN;   // 3 deneme de bitti → reset
	                }
	            }
	            break;
	    }

	    //switch case bittiği nokta





  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */

  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 255;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 1920-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 1000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8|GPIO_PIN_11, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PB12 PB14 */
  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PA8 PA11 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_11;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
// UART kesme callback fonksiyonu
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART1) {
        // Gelen karakter \r veya \n değilse ve buffer dolmadıysa
        if (rx_data != '\r' && rx_data != '\n' && rx_index < RX_BUFFER_SIZE - 1) {
            rx_buffer[rx_index++] = rx_data; // Karakteri buffer'a ekle
        } else {
            rx_buffer[rx_index] = '\0'; // String sonlandırıcı ekle
            line_ready = 1;   //  sadece bayrak koy
            rx_index = 0;
            if (rx_index > 0) { // Buffer boş değilse
                // Eğer veri 17 karakterden uzunsa
                if (rx_index > 17) {
                    // İlk 17 karakteri al
                    char first_part[18];
                    strncpy(first_part, (char*)rx_buffer, 17);
                    first_part[17] = '\0'; // İlk kısmı sonlandır

                    // Kalan kısmı al (18. karakterden itibaren)
                    char *second_part = (char*)(rx_buffer + 17);

                    // OLED ekranına yazdır
                    OLED_Print("Alinan Veri:", first_part, second_part);
                    //HAL_UART_Transmit(&huart1, (uint8_t*)"STM32-OK\r\n", 12, HAL_MAX_DELAY);
                } else {
                    // 17 karakter veya daha kısa ise, sadece ikinci satıra yaz
                    OLED_Print("Alinan Veri:", (char*)rx_buffer, "");
                    //HAL_UART_Transmit(&huart1, (uint8_t*)"STM32-OK\r\n", 12, HAL_MAX_DELAY);
                }
            }
            rx_index = 0; // Buffer'ı sıfırla
        }
        // Tekrar kesme ile veri almaya devam et
        HAL_UART_Receive_IT(&huart1, &rx_data, 1);
    }
}
void ParseObjectData(char *str)
{
    char *pStart = NULL;
    char *pEnd   = NULL;

    if (strncmp(str, "plastik(", 8) == 0)
    {
        detectedObject = OBJ_PLASTIC;
        pStart = str + 8;
    }
    else if (strncmp(str, "metal(", 6) == 0)
    {
        detectedObject = OBJ_METAL;
        pStart = str + 6;
    }
    else if (strncmp(str, "cam(", 4) == 0)
    {
        detectedObject = OBJ_GLASS;
        pStart = str + 4;
    }
    else
    {
        return;
    }

    pEnd = strchr(pStart, ')');
    if (pEnd == NULL) return;

    *pEnd = '\0';     // "360)" → "360"

    detectedDistance = atoi(pStart);   // SADECE INT
    capture_done = 1;

    if (detectedObject == OBJ_PLASTIC) OLED_Print("OBJ", "PLASTIK", "");
    if (detectedObject == OBJ_METAL)   OLED_Print("OBJ", "METAL", "");
    if (detectedObject == OBJ_GLASS)   OLED_Print("OBJ", "CAM", "");
}


void ESP_SendCapture(void)
{
    capture_done = 0;
    detectedObject = OBJ_NONE;
    detectedDistance = 0;

    HAL_UART_Transmit(&huart1, (uint8_t*)"capture\n", 8, HAL_MAX_DELAY);
    OLED_Print("ESP", "capture", "sent");
}
//kol fonksiyonları------------------------------
// Yeni X aralıklarına göre (0-550) servoları hareket ettiren fonksiyon
void Move_Servos_By_X(float x, uint32_t my_arr) {
    float pa7_duty, pb0_duty;

    // --- SİSTEM KORUMASI (0-550 dışına çıkmayı engeller) ---
    if (x < 0.0f) x = 0.0f;
    if (x > 550.0f) x = 550.0f;

    // YENİ GRAFİK MANTIĞI
    if (x <= 31.0f) {
        // x = 0-31 Arası Sabit
        pa7_duty = 5.7f;
        pb0_duty = 8.3f;
    }
    else if (x > 31.0f && x < 159.0f) {
        // 31-159 Arası Geçiş (Birinci İniş)
        pa7_duty = lerp(x, 31.0f, 159.0f, 5.7f, 4.0f);
        pb0_duty = lerp(x, 31.0f, 159.0f, 8.3f, 6.3f);
    }
    else if (x >= 159.0f && x <= 266.0f) {
        // x = 159-266 Arası Sabit
        pa7_duty = 4.0f;
        pb0_duty = 6.3f;
    }
    else if (x > 266.0f && x < 480.0f) {
        // 266-480 Arası Geçiş (İkinci İniş)
        pa7_duty = lerp(x, 266.0f, 480.0f, 4.0f, 3.0f);
        pb0_duty = lerp(x, 266.0f, 480.0f, 6.3f, 4.7f);
    }
    else {
        // x = 480-550 Arası Sabit
        pa7_duty = 3.0f;
        pb0_duty = 4.7f;
    }

    // PWM Kayıtçılarını (CCR) Güncelle (ARR 20000'e göre)
    // Formül: (Duty / 100) * 20000
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, (uint32_t)((pa7_duty * my_arr) / 100.0f));
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, (uint32_t)((pb0_duty * my_arr) / 100.0f));
}

// Mevcut konumu takip ederek yavaşça gitme fonksiyonu
// Not: current_x değişkenini Private Variables (PV) kısmında tanımlamayı unutma.

void Go_To_X_Slowly(float target_x, float speed, uint32_t my_arr) {
    if (target_x < 0.0f) target_x = 0.0f;
    if (target_x > 550.0f) target_x = 550.0f;

    while (current_x != target_x) {
        if (current_x < target_x) {
            current_x += 1.0f;
            if (current_x > target_x) current_x = target_x;
        }
        else {
            current_x -= 1.0f;
            if (current_x < target_x) current_x = target_x;
        }

        Move_Servos_By_X(current_x, my_arr);
        HAL_Delay((uint32_t)speed);
    }
}
void Set_PWM_Duty_TIM3(uint8_t channel, uint16_t duty10)
{
    if (duty10 > 1000) duty10 = 1000;  // max = 100.0%

    // integer math only
    uint32_t compare = ((uint32_t)(htim3.Init.Period + 1) * duty10) / 1000;

    switch(channel)
    {
        case 1: __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, compare); break;
        case 2: __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, compare); break;
        case 3: __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, compare); break;
        case 4: __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, compare); break;
    }
}

void Metal_Object(void)
{
     Set_PWM_Duty_TIM3(1, 70); //PA6  Taban (20-120 def-70)
     Set_PWM_Duty_TIM3(2, 60); //PA7  Omuz (def-60)
     Set_PWM_Duty_TIM3(3, 75); //PB0  dirsek (def-75 , max-99)
	   Set_PWM_Duty_TIM3(4, 50); //PB1  Grapper(50-default , grab-76-77)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(3, 80);
	   HAL_Delay(1000);
 	   Go_To_X_Slowly(detectedDistance, 10 , my_arr);
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(4, 77); //PB1  Grapper(50-default , grab-76-77)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(2, 60); //PA7  Omuz (def-60)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(3, 75); //PB0  dirsek (def-75 , max-99)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(1, 20); //PA6  Taban (20-120 def-70)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(2, 50); //koymadan önce eğilme
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(4, 50); //PB1  Grapper(50-default , grab-76-77)
	   HAL_Delay(1000);
	   current_x=0.0f;

}
void Plastic_Object(void)
{
     Set_PWM_Duty_TIM3(1, 70); //PA6  Taban (20-120 def-70)
     Set_PWM_Duty_TIM3(2, 60); //PA7  Omuz (def-60)
     Set_PWM_Duty_TIM3(3, 75); //PB0  dirsek (def-75 , max-99)
	   Set_PWM_Duty_TIM3(4, 50); //PB1  Grapper(50-default , grab-76-77)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(3, 80);
	   HAL_Delay(1000);
 	   Go_To_X_Slowly(detectedDistance, 10 , my_arr);
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(4, 77); //PB1  Grapper(50-default , grab-76-77)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(2, 60); //PA7  Omuz (def-60)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(3, 75); //PB0  dirsek (def-75 , max-99)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(1, 120); //PA6  Taban (20-120 def-70)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(2, 50); //koymadan önce eğilme
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(4, 50); //PB1  Grapper(50-default , grab-76-77)
	   HAL_Delay(1000);
	   current_x=0.0f;
}
void Glass_Object(void)
{
     Set_PWM_Duty_TIM3(1, 70); //PA6  Taban (20-120 def-70)
     Set_PWM_Duty_TIM3(2, 60); //PA7  Omuz (def-60)
     Set_PWM_Duty_TIM3(3, 75); //PB0  dirsek (def-75 , max-99)
	   Set_PWM_Duty_TIM3(4, 50); //PB1  Grapper(50-default , grab-76-77)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(3, 80);
	   HAL_Delay(1000);
 	   Go_To_X_Slowly(detectedDistance, 10 , my_arr);
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(4, 77); //PB1  Grapper(50-default , grab-76-77)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(2, 60); //PA7  Omuz (def-60)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(3, 75); //PB0  dirsek (def-75 , max-99)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(1, 105); //PA6  Taban (20-120 def-70)
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(2, 50); //koymadan önce eğilme
	   HAL_Delay(1000);
	   Set_PWM_Duty_TIM3(4, 50); //PB1  Grapper(50-default , grab-76-77)
	   HAL_Delay(1000);
	   current_x=0.0f;
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
