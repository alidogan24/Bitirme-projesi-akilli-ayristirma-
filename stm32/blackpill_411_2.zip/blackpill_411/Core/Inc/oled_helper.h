/*
 * oled_helper.h
 *
 *  Created on: Sep 25, 2025
 *      Author: Acer
 */

#ifndef INC_OLED_HELPER_H_
#define INC_OLED_HELPER_H_

#include "ssd1306.h"
#include "fonts.h"
#include <stdio.h>
#include <string.h>

// Kullanıcı fonksiyonları
void OLED_Print(const char *bigText, const char *smallText1, const char *smallText2);
void OLED_PrintVar(const char *label, int intVal, float floatVal);

#endif /* INC_OLED_HELPER_H_ */
